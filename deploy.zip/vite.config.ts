import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  server: {
    proxy: {
      '/render-api': {
        target: 'https://apiserverpro.onrender.com',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/render-api/, ''),
        headers: {
          'Origin': 'https://deltastudy.site',
          'Referer': 'https://deltastudy.site/',
        },
      },
      '/api': 'http://localhost:5174',
      '/stream': 'http://localhost:5174',
    },
  },
  build: {
    sourcemap: 'hidden',
  },
  plugins: [
    react({
      babel: {
        plugins: [
          'react-dev-locator',
        ],
      },
    }),
    tsconfigPaths()
  ],
})
