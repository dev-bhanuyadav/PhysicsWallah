import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  GraduationCap,
  Pi,
  Library,
  Layers,
  Zap,
  ClipboardList,
  Award,
  MapPin,
  ChevronRight,
  User,
  Menu,
  X
} from 'lucide-react';
import WelcomeModal from './WelcomeModal';

export default function Layout({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [userName, setUserName] = useState('');
  const [userClass, setUserClass] = useState('Dropper - IIT JEE');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    setIsMobileMenuOpen(false); // Close menu on navigation
  }, [location.pathname]);

  useEffect(() => {
    const updateUserData = () => {
      setUserName(localStorage.getItem('pw_user_name') || '');
      const cls = localStorage.getItem('pw_user_class');
      if (cls) setUserClass(cls);
    };
    updateUserData();
    window.addEventListener('storage', updateUserData);
    return () => window.removeEventListener('storage', updateUserData);
  }, []);

  return (
    <div className="min-h-screen bg-white text-slate-900 font-sans flex flex-col">
      <WelcomeModal />
      
      {/* Top Header */}
      <header className="h-14 sm:h-16 flex items-center px-4 sm:px-6 border-b border-slate-200 bg-white sticky top-0 z-40">
        <button 
          className="mr-3 p-1.5 lg:hidden text-slate-600 rounded-lg hover:bg-slate-100"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
        
        <div className="flex items-center gap-2 sm:gap-3 mr-4 sm:mr-10 cursor-pointer" onClick={() => navigate('/')}>
          <img 
            src="https://images.seeklogo.com/logo-png/47/1/physics-wallah-logo-png_seeklogo-474856.png" 
            alt="Physics Wallah" 
            className="h-7 w-7 sm:h-8 sm:w-8 object-contain"
          />
          <span className="font-bold text-[17px] sm:text-[19px] tracking-tight text-slate-900 truncate">Physics Wallah</span>
        </div>

        <div className="flex-1"></div>

        <div className="flex items-center gap-5">
          <div className="flex items-center gap-3 pl-5 border-l border-slate-200">
            <span className="text-sm font-bold hidden sm:block">Hi, {userName || 'Student'}</span>
            <div className="w-9 h-9 rounded-full bg-amber-100 flex items-center justify-center border border-amber-200 text-amber-600">
              <User size={18} />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex-1 flex max-w-[1500px] w-full mx-auto relative">
        {/* Mobile Menu Overlay */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-slate-900/40 z-40 lg:hidden backdrop-blur-sm transition-opacity"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-50 w-[260px] bg-white border-r border-slate-200 overflow-y-auto pt-6 pb-10 transition-transform duration-300 ease-in-out lg:relative lg:translate-x-0
          ${isMobileMenuOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
        `}>
          <div className="flex items-center justify-between px-6 mb-6 lg:hidden">
            <span className="font-bold text-lg">Menu</span>
            <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 text-slate-500 rounded-full bg-slate-100">
              <X size={20} />
            </button>
          </div>
          <div className="px-4">
            <div className="px-3 text-[11px] font-black tracking-widest text-slate-400 uppercase mb-3">
              Learn Online
            </div>
            <div className="space-y-1 text-slate-600 font-medium text-sm">
              <SidebarItem icon={GraduationCap} label="Study" path="/" active={location.pathname === '/'} />
              <SidebarItem icon={Layers} label="Batches" path="/batches" active={location.pathname === '/batches'} />
            </div>
          </div>
        </aside>

        {/* Page Content */}
        <main className="flex-1 bg-white min-w-0">
          {children}
        </main>
      </div>
    </div>
  );
}

function SidebarItem({ 
  icon: Icon, 
  label, 
  path, 
  active, 
  badge 
}: { 
  icon: any; 
  label: string; 
  path: string; 
  active: boolean;
  badge?: string;
}) {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(path)}
      className={`w-full flex items-center justify-between px-3 py-3 rounded-xl transition-all ${
        active 
          ? 'bg-indigo-50/80 text-indigo-600 font-bold' 
          : 'hover:bg-slate-50 text-slate-600 font-medium hover:text-slate-900'
      }`}
    >
      <div className="flex items-center gap-3">
        <Icon size={20} className={active ? 'text-indigo-600' : 'text-slate-400'} />
        <span>{label}</span>
      </div>
      {badge && (
        <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider">
          {badge}
        </span>
      )}
    </button>
  );
}
