import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2, Edit2 } from 'lucide-react';
import { createBatch, isGlobalBatchesEnabled, listBatches, removeBatch, seedIfEmpty, updateBatchId, type Batch } from '@/lib/batchesStorage';

function formatINR(n: number) {
  return `₹${n.toLocaleString('en-IN')}`;
}

export default function Admin() {
  const navigate = useNavigate();
  const isAdmin = sessionStorage.getItem('pw_admin') === '1';
  const [refreshKey, setRefreshKey] = useState(0);
  const [toast, setToast] = useState<string | null>(null);
  const [keyValue, setKeyValue] = useState('');
  const [keyLoading, setKeyLoading] = useState(false);
  const [keyError, setKeyError] = useState('');
  const [adminKey, setAdminKey] = useState('');
  const [batches, setBatches] = useState<Batch[]>([]);
  const [batchesLoading, setBatchesLoading] = useState(false);

  const [batchIdInput, setBatchIdInput] = useState('');
  const [title, setTitle] = useState('');
  const [subtitle, setSubtitle] = useState('');
  const [examLabel, setExamLabel] = useState('');
  const [language, setLanguage] = useState('HINGLISH');
  const [startDate, setStartDate] = useState('');
  const [price, setPrice] = useState<string>('');
  const [originalPrice, setOriginalPrice] = useState<string>('');
  const [imageUrl, setImageUrl] = useState('');
  const [isOffline, setIsOffline] = useState(false);
  const [hasMultiplePlans, setHasMultiplePlans] = useState(true);

  // PW Token State
  const [pwToken, setPwToken] = useState('');
  const [dbToken, setDbToken] = useState('');

  useEffect(() => {
    let alive = true;
    (async () => {
      setBatchesLoading(true);
      try {
        if (!isGlobalBatchesEnabled()) seedIfEmpty();
        const next = await listBatches();
        if (alive) setBatches(next);
      } finally {
        if (alive) setBatchesLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [refreshKey]);

  const showToast = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast(null), 1800);
  };

  const unlockAdmin = async () => {
    const expectedHash = '23d47445adfb8991789b459b6ba1b974d727d310aa9d80b7c2875b9430c0ba25'; // pw123
    setKeyLoading(true);
    setKeyError('');
    try {
      const enc = new TextEncoder();
      const buf = await crypto.subtle.digest('SHA-256', enc.encode(keyValue));
      const hash = Array.from(new Uint8Array(buf))
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
      if (hash !== expectedHash) {
        setKeyError('Wrong key');
        return;
      }
      sessionStorage.setItem('pw_admin', '1');
      setAdminKey(keyValue);
      setKeyValue('');
      showToast('Admin unlocked');
      setRefreshKey((k) => k + 1);
    } finally {
      setKeyLoading(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-[#000A1F] text-white font-sans flex items-center justify-center px-6">
        {toast && (
          <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[200] px-4 w-full max-w-md">
            <div className="rounded-2xl px-5 py-4 border shadow-2xl backdrop-blur-xl bg-white/10 border-white/15">
              <div className="text-sm font-black tracking-wide">{toast}</div>
            </div>
          </div>
        )}
        <div className="max-w-md w-full rounded-[24px] bg-white/5 border border-white/10 p-8">
          <div className="text-2xl font-black tracking-tight text-center">Admin Panel</div>
          <div className="mt-3 text-white/50 font-medium text-center">
            Admin access ke liye key enter karo.
          </div>

          <div className="mt-8 space-y-3">
            <div className="text-xs font-black tracking-widest uppercase text-white/50">Admin Key</div>
            <input
              value={keyValue}
              onChange={(e) => setKeyValue(e.target.value)}
              type="password"
              className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 outline-none focus:border-blue-500/40"
              placeholder="Enter key"
            />
            {keyError && <div className="text-red-300 text-sm font-black">{keyError}</div>}
          </div>

          <button
            onClick={unlockAdmin}
            disabled={keyLoading || !keyValue.trim()}
            className={`mt-6 w-full py-4 rounded-2xl font-black tracking-widest text-sm transition-all active:scale-95 ${
              keyValue.trim()
                ? 'bg-blue-600 hover:bg-blue-700 text-white'
                : 'bg-white/10 text-white/50 cursor-not-allowed'
            }`}
          >
            {keyLoading ? 'UNLOCKING...' : 'UNLOCK ADMIN'}
          </button>

          <button
            onClick={() => navigate('/batches')}
            className="mt-4 w-full bg-white/5 border border-white/10 hover:bg-white/10 transition-all py-4 rounded-2xl font-black tracking-widest text-sm"
          >
            BACK
          </button>
        </div>
      </div>
    );
  }

  const onAdd = async () => {
    const p = Number(price);
    const op = Number(originalPrice);
    if (!title.trim()) return showToast('Title required');
    if (!subtitle.trim()) return showToast('Subtitle required');
    if (!examLabel.trim()) return showToast('Exam label required');
    if (!startDate) return showToast('Start date required');
    if (!Number.isFinite(p) || p <= 0) return showToast('Price invalid');
    if (!Number.isFinite(op) || op <= 0) return showToast('Original price invalid');
    if (!imageUrl.trim()) return showToast('Image URL required');
    if (!adminKey.trim()) return showToast('Enter admin key again');

    await createBatch(
      {
        id: batchIdInput.trim() || undefined,
        title: title.trim(),
        subtitle: subtitle.trim(),
        examLabel: examLabel.trim(),
        language,
        startDate,
        price: p,
        originalPrice: op,
        imageUrl: imageUrl.trim(),
        isOffline,
        hasMultiplePlans,
      },
      adminKey.trim(),
    );

    setBatchIdInput('');
    setTitle('');
    setSubtitle('');
    setExamLabel('');
    setLanguage('HINGLISH');
    setStartDate('');
    setPrice('');
    setOriginalPrice('');
    setImageUrl('');
    setIsOffline(false);
    setHasMultiplePlans(true);
    setRefreshKey((k) => k + 1);
    showToast('Batch added');
  };

  const handleSaveToken = async () => {
    try {
      const res = await fetch('/api/v1/admin/settings/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-admin-key': adminKey.trim() },
        body: JSON.stringify({ token: pwToken })
      });
      if (res.ok) {
        showToast('PW Token Encrypted & Saved!');
        setPwToken('');
      } else {
        const d = await res.json();
        showToast(`Error: ${d.error || 'Failed to save'}`);
      }
    } catch {
      showToast('Network error');
    }
  };

  const onDelete = async (id: string) => {
    if (!adminKey.trim()) return showToast('Enter admin key again');
    await removeBatch(id, adminKey.trim());
    setRefreshKey((k) => k + 1);
    showToast('Batch deleted');
  };

  const onEditId = async (id: string) => {
    if (!adminKey.trim()) return showToast('Enter admin key again');
    const newId = window.prompt('Enter real PW Batch ID to replace this UUID:', id);
    if (!newId || newId.trim() === id || !newId.trim()) return;
    await updateBatchId(id, newId.trim(), adminKey.trim());
    setRefreshKey((k) => k + 1);
    showToast('Batch ID updated');
  };

  return (
    <div className="min-h-screen bg-[#000A1F] text-white font-sans">
      {toast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-[200] px-4 w-full max-w-md">
          <div className="rounded-2xl px-5 py-4 border shadow-2xl backdrop-blur-xl bg-white/10 border-white/15">
            <div className="text-sm font-black tracking-wide">{toast}</div>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
        <div className="flex items-center justify-between gap-4">
          <button
            onClick={() => navigate('/batches')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all"
          >
            <ArrowLeft size={18} />
            <span className="text-sm font-black tracking-widest uppercase">Back</span>
          </button>

          <div className="text-sm font-black tracking-widest uppercase text-white/50">
            Admin Panel
          </div>
        </div>

        {!adminKey && (
          <div className="mt-8 rounded-[24px] bg-white/5 border border-white/10 p-6 sm:p-8 backdrop-blur-xl">
            <div className="text-lg font-black tracking-tight">Admin Key Required</div>
            <div className="mt-2 text-white/50 font-medium">
              Changes save karne ke liye admin key enter karo.
            </div>
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <input
                value={keyValue}
                onChange={(e) => setKeyValue(e.target.value)}
                type="password"
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-4 py-4 outline-none focus:border-blue-500/40"
                placeholder="Enter key"
              />
              <button
                onClick={unlockAdmin}
                disabled={keyLoading || !keyValue.trim()}
                className={`shrink-0 w-full sm:w-auto px-6 py-4 rounded-2xl font-black tracking-widest text-sm transition-all active:scale-95 ${
                  keyValue.trim()
                    ? 'bg-blue-600 hover:bg-blue-700 text-white'
                    : 'bg-white/10 text-white/50 cursor-not-allowed'
                }`}
              >
                {keyLoading ? 'UNLOCKING...' : 'UNLOCK'}
              </button>
            </div>
            {keyError && <div className="mt-3 text-red-300 text-sm font-black">{keyError}</div>}
          </div>
        )}

        <div className="mt-10 grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="rounded-[24px] bg-white/5 border border-white/10 p-6 sm:p-8 backdrop-blur-xl">
            <div className="text-xl font-black tracking-tight">Add Batch</div>
            <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <label className="space-y-2 col-span-1 sm:col-span-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">PW Batch ID (Optional)</div>
                <input
                  value={batchIdInput}
                  onChange={(e) => setBatchIdInput(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="e.g. 698ad35209494b495cfcc9c4"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Title</div>
                <input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="Yakeen NEET 2027"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Subtitle</div>
                <input
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="Class 12+ • NEET"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Exam Label</div>
                <input
                  value={examLabel}
                  onChange={(e) => setExamLabel(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="NEET 2027"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Language</div>
                <select
                  value={language}
                  onChange={(e) => setLanguage(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                >
                  <option value="HINGLISH">HINGLISH</option>
                  <option value="HINDI">HINDI</option>
                  <option value="ENGLISH">ENGLISH</option>
                </select>
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Start Date</div>
                <input
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  type="date"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Price (₹)</div>
                <input
                  value={price}
                  onChange={(e) => setPrice(e.target.value.replace(/[^\d]/g, ''))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="5200"
                />
              </label>

              <label className="space-y-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Original Price (₹)</div>
                <input
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value.replace(/[^\d]/g, ''))}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="6000"
                />
              </label>

              <label className="space-y-2 sm:col-span-2">
                <div className="text-xs font-black tracking-widest uppercase text-white/50">Image URL</div>
                <input
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-blue-500/40"
                  placeholder="https://..."
                />
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={hasMultiplePlans}
                  onChange={(e) => setHasMultiplePlans(e.target.checked)}
                  className="w-5 h-5 rounded border-white/10"
                />
                <span className="text-sm font-bold text-white/80">Has Multiple Plans (Infinity/Pro)</span>
              </label>

              <label className="flex items-center gap-3">
                <input
                  type="checkbox"
                  checked={isOffline}
                  onChange={(e) => setIsOffline(e.target.checked)}
                  className="w-5 h-5 rounded border-white/10"
                />
                <span className="text-sm font-bold text-white/80">Offline Centre (Vidyapeeth)</span>
              </label>
            </div>

            <button
              onClick={onAdd}
              className="mt-6 w-full bg-blue-600 text-white py-4 rounded-2xl font-black tracking-widest text-sm hover:bg-blue-700 transition-all active:scale-95 inline-flex items-center justify-center gap-3"
            >
              <Plus size={18} />
              ADD BATCH
            </button>

            <div className="mt-6 text-white/40 text-xs font-bold">
              Preview: {formatINR(Number(price || 0))} / {formatINR(Number(originalPrice || 0))}
            </div>
          </div>

          <div className="rounded-[24px] bg-white/5 border border-white/10 p-6 sm:p-8 backdrop-blur-xl">
            <div className="flex items-center justify-between gap-4">
              <div className="text-xl font-black tracking-tight">All Batches</div>
              <div className="text-xs font-black tracking-widest uppercase text-white/40">
                {batches.length}
              </div>
            </div>

            <div className="mt-6 space-y-4">
              {batchesLoading && (
                <>
                  {Array.from({ length: 3 }).map((_, i) => (
                    <div
                      key={i}
                      className="rounded-2xl bg-white/5 border border-white/10 p-4 h-[72px]"
                    />
                  ))}
                </>
              )}
              {batches.map((b: Batch) => (
                <div
                  key={b.id}
                  className="rounded-2xl bg-white/5 border border-white/10 p-4 flex items-center justify-between gap-4"
                >
                  <div className="min-w-0 pr-4">
                    <div className="font-black truncate block">{b.title}</div>
                    <div className="text-white/50 text-xs truncate mt-0.5">ID: {b.id}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onEditId(b.id)}
                      className="shrink-0 inline-flex items-center justify-center w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-blue-400"
                      title="Edit Batch ID"
                    >
                      <Edit2 size={16} />
                    </button>
                    <button
                      onClick={() => onDelete(b.id)}
                      className="shrink-0 inline-flex items-center justify-center w-10 h-10 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all text-red-400"
                      title="Delete Batch"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                </div>
              ))}

              {!batchesLoading && !batches.length && (
                <div className="text-white/40 text-sm font-bold">No batches yet.</div>
              )}
            </div>
            <div className="border-t border-white/10 mt-12 pt-12">
              <h2 className="text-xl font-bold mb-2">Advanced Synchronization</h2>
              <p className="text-white/50 text-sm mb-6 max-w-lg">
                If you have a PW Access Token (`access_token` from authorization response), provide it here. The website will automatically fetch rich data (Demo Videos, etc) from `api.penpencil.co` on the Course Details page!
              </p>
              
              <div className="flex items-end gap-4 max-w-xl">
                <label className="space-y-2 flex-1">
                  <div className="text-xs font-black tracking-widest uppercase text-white/50">PW Bearer Token</div>
                  <input
                    value={pwToken}
                    onChange={(e) => setPwToken(e.target.value)}
                    type="password"
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 outline-none focus:border-emerald-500/40"
                    placeholder="eyJh..."
                  />
                </label>
                <button
                  onClick={handleSaveToken}
                  className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl transition-all"
                >
                  Save Token
                </button>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

