import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import React, { Suspense } from 'react';
import Layout from "@/components/Layout";

// Optimize for low-end devices by lazily loading large page components
const Home = React.lazy(() => import('@/pages/Home'));
const Batches = React.lazy(() => import('@/pages/Batches'));
const BatchDetails = React.lazy(() => import('@/pages/BatchDetails'));
const SubjectTopics = React.lazy(() => import('@/pages/SubjectTopics'));
const TopicContents = React.lazy(() => import('@/pages/TopicContents'));
const VideoPlayer = React.lazy(() => import('@/pages/VideoPlayer'));
const Admin = React.lazy(() => import('@/pages/Admin'));

const LoadingFallback = () => (
  <div className="min-h-screen w-full flex items-center justify-center bg-white">
    <div className="w-10 h-10 border-4 border-slate-200 border-t-amber-500 rounded-full animate-spin"></div>
  </div>
);

export default function App() {
  return (
    <Router>
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
          {/* Landing Page with its own Nav */}
          <Route path="/" element={<Home />} />
          
          {/* Dashboard Pages with Sidebar/Navbar */}
          <Route path="/batches" element={<Layout><Batches /></Layout>} />
          <Route path="/batches/:id" element={<Layout><BatchDetails /></Layout>} />
          <Route path="/batches/:batchId/subjects/:subjectId" element={<Layout><SubjectTopics /></Layout>} />
          <Route path="/batches/:batchId/subjects/:subjectId/topics/:topicSlug" element={<Layout><TopicContents /></Layout>} />
          <Route path="/batches/:batchId/subjects/:subjectId/video/:childId" element={<Layout><VideoPlayer /></Layout>} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/other" element={<Layout><div className="text-center text-xl mt-12 w-full">Coming Soon</div></Layout>} />
        </Routes>
      </Suspense>
    </Router>
  );
}
