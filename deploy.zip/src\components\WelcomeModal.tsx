import React, { useState, useEffect } from 'react';

export default function WelcomeModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [name, setName] = useState('');

  useEffect(() => {
    const storedName = localStorage.getItem('pw_user_name');
    if (!storedName) {
      setIsOpen(true);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      localStorage.setItem('pw_user_name', name.trim());
      // Default class so Layout doesn't break if it expects it
      if (!localStorage.getItem('pw_user_class')) {
        localStorage.setItem('pw_user_class', 'Dropper - IIT JEE');
      }
      setIsOpen(false);
      window.dispatchEvent(new Event('storage'));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="bg-slate-900 px-6 py-6 text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 rounded-full bg-white flex items-center justify-center font-black text-xl">
              PW
            </div>
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white mb-1">Welcome to Physics Wallah</h2>
          <p className="text-slate-400 font-medium text-sm">Please tell us your name</p>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div>
            <label className="block text-sm font-bold text-slate-700 mb-1.5">What's your name?</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Rahul"
              required
              className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 outline-none transition-all font-semibold"
            />
          </div>
          <button
            type="submit"
            className="w-full py-3.5 bg-slate-900 text-white rounded-xl font-black tracking-wide shadow-[0_10px_18px_rgba(15,23,42,0.18)] active:scale-[0.98] transition-all mt-2"
          >
            Continue to App
          </button>
        </form>
      </div>
    </div>
  );
}
