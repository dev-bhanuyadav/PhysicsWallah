import React, { useState, useEffect, useMemo } from 'react';
import { Search, ChevronRight, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { isGlobalBatchesEnabled, listBatches, seedIfEmpty, type Batch } from '@/lib/batchesStorage';

function formatINR(n: number) {
  return `₹${n.toLocaleString('en-IN')}`;
}

export default function Batches() {
  const navigate = useNavigate();
  const [q, setQ] = useState('');
  const [allBatches, setAllBatches] = useState<Batch[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      setLoading(true);
      try {
        if (!isGlobalBatchesEnabled()) seedIfEmpty();
        const data = await listBatches();
        if (alive) setAllBatches(data);
      } finally {
        if (alive) setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, []);

  const batches = useMemo(() => {
    const query = q.trim().toLowerCase();
    if (!query) return allBatches;
    return allBatches.filter((b) => {
      const hay = `${b.title} ${b.subtitle} ${b.examLabel} ${b.language}`.toLowerCase();
      return hay.includes(query);
    });
  }, [q, allBatches]);

  return (
    <div className="p-8 w-full max-w-6xl">
      {/* Top action bar */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-xl font-bold tracking-tight text-slate-900">Batches</h1>
        <div className="flex items-center gap-3 w-[380px] px-4 py-2.5 bg-white border border-slate-200 rounded-lg">
          <Search size={18} className="text-slate-400" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search for batches"
            className="w-full bg-transparent outline-none border-none text-slate-900 placeholder:text-slate-400 text-sm font-medium"
          />
        </div>
      </div>

      <h2 className="text-[28px] font-medium tracking-tight text-slate-800 mb-6">Popular Courses</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading && Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="rounded-2xl border bg-white border-slate-200 h-[460px] animate-pulse"></div>
        ))}
        {!loading && batches.map((course) => {
          const isOffline = course.isOffline;
          const offPercent = course.originalPrice > course.price ? Math.round((1 - course.price/course.originalPrice) * 100) : 0;
          
          return (
            <div 
              key={course.id} 
              onClick={() => navigate(`/batches/${course.id}`)}
              className={`rounded-[26px] border overflow-hidden flex flex-col cursor-pointer transition-all hover:scale-[1.02] hover:-translate-y-1 hover:shadow-2xl ${
                isOffline 
                  ? 'bg-[#1b212f] border-[#2d3748] text-white hover:border-slate-500' 
                  : 'bg-white border-slate-200 text-slate-900 shadow-[0_16px_40px_rgba(15,23,42,0.12)] hover:border-indigo-300'
              }`}
            >
              {/* Banner */}
              <div className={`py-1.5 px-4 text-xs font-bold flex items-center gap-1.5 ${
                isOffline ? 'bg-[#2d3748]' : 'bg-slate-100'
              }`}>
                {!isOffline && course.hasMultiplePlans && <span className="text-amber-500">❖</span>}
                {isOffline && <span className="w-2 h-2 rounded-full bg-orange-400"></span>}
                <span className={isOffline ? 'text-slate-200 tracking-wide' : 'text-slate-600'}>
                  {isOffline ? 'OFFLINE CENTRE' : course.hasMultiplePlans ? 'Multiple plans inside: Infinity, Pro' : 'Single Batch'}
                </span>
              </div>

              {/* Image */}
              <div className="relative w-full pt-[58%] sm:pt-[52%] bg-slate-200">
                <img
                  src={course.imageUrl}
                  alt={course.title}
                  className="absolute inset-0 w-full h-full object-cover object-center"
                  loading="lazy"
                />
              </div>

              {/* Content Details */}
              <div className="p-5 sm:px-6 pt-5 pb-6 flex-1 flex flex-col">
                <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                  <span className={`text-[13px] font-black tracking-tight ${isOffline ? 'text-amber-500' : 'text-orange-500'}`}>
                    {course.subtitle}
                  </span>
                  <span className={`text-[11px] font-black tracking-widest px-2 py-0.5 rounded border ${
                    isOffline 
                      ? 'border-[#2d3748] text-slate-300 bg-[#2d3748]/50' 
                      : 'border-slate-200 text-slate-800 bg-white'
                  }`}>
                    {course.language.toUpperCase()}
                  </span>
                </div>

                <h3 className="text-2xl font-black tracking-tight mb-4">
                  {course.title}
                </h3>

                {isOffline ? (
                  <div className="space-y-2 mb-6 text-sm text-slate-300 font-medium">
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={16} className="text-slate-400 mt-0.5 shrink-0" />
                      <span>Experienced Faculty</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={16} className="text-slate-400 mt-0.5 shrink-0" />
                      <span>Tech-enabled Offline Classroom Lear...</span>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle2 size={16} className="text-slate-400 mt-0.5 shrink-0" />
                      <span>Batch starting from mid-march</span>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2 mb-6 text-sm text-slate-700 font-bold">
                    <div className="flex items-center gap-3">
                      <span className="opacity-60">📖</span> {course.examLabel}
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="opacity-60">📅</span> Starts on {course.startDate}
                    </div>
                  </div>
                )}

                <div className="mt-auto pt-4 flex items-end justify-between">
                  <div>
                    <div className="flex items-end gap-2">
                      <span className="text-2xl font-black">{formatINR(course.price)}</span>
                      <span className={`text-sm font-bold line-through pb-0.5 ${
                        isOffline ? 'text-slate-500' : 'text-slate-400'
                      }`}>
                        {formatINR(course.originalPrice)}
                      </span>
                    </div>
                    {!isOffline && offPercent > 0 && (
                      <div className="text-emerald-600 font-black text-sm mt-0.5">
                        {offPercent}% OFF
                      </div>
                    )}
                    {isOffline && (
                      <div className="text-slate-400 text-xs mt-0.5 font-medium">
                        For Registration
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <button className={`h-11 px-7 rounded-xl text-sm font-black transition-all shadow-[0_10px_18px_rgba(15,23,42,0.18)] active:scale-95 ${
                      isOffline 
                        ? 'bg-white text-slate-900 hover:bg-slate-100' 
                        : 'bg-slate-900 text-white hover:bg-slate-800'
                    }`}>
                      {isOffline ? 'Book A Seat' : 'Buy Now'}
                    </button>
                    <button className={`h-11 w-11 flex items-center justify-center rounded-xl border transition-all active:scale-95 ${
                      isOffline
                        ? 'border-slate-600 hover:bg-slate-800 text-slate-300'
                        : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-800'
                    }`}>
                      <ChevronRight size={18} />
                    </button>
                  </div>
                </div>
              </div>

            </div>
          );
        })}
      </div>
      {!loading && batches.length === 0 && (
        <div className="text-center mt-12 text-slate-500 font-medium">No batches found. Try exploring the Admin panel!</div>
      )}
    </div>
  );
}
