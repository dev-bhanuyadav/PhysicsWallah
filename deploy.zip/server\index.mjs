import { createServer } from 'node:http';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import crypto, { createHash, randomUUID, createDecipheriv, createCipheriv, randomBytes } from 'node:crypto';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, 'data');
const DATA_FILE = join(DATA_DIR, 'batches.json');
const DATA_TOKEN_FILE = join(DATA_DIR, 'secure_config.json');
const PORT = Number(process.env.PORT || 5174);

const expectedKeyHash =
  process.env.ADMIN_KEY_SHA256 ||
  '277839a853d9eb79ebd2fb5dd66e929021c8948721cd2aabc6e2be42da0a2d5e';

function sha256(s) {
  return createHash('sha256').update(String(s)).digest('hex');
}

// Custom Encryption to protect our API responses
function encryptPayload(dataObj, keyString) {
  const iv = randomBytes(12);
  const sha256Buffer = createHash('sha256').update(keyString).digest();
  
  const cipher = createCipheriv('aes-256-gcm', sha256Buffer, iv);
  let encrypted = cipher.update(JSON.stringify(dataObj), 'utf8');
  let finalEnd = cipher.final();
  const tag = cipher.getAuthTag();
  
  // Custom Obfuscation: Merge everything into raw bytes, base64 it, and reverse it!
  // Normal script-kiddies won't even know it's AES-GCM.
  const combinedBuffer = Buffer.concat([iv, tag, encrypted, finalEnd]);
  const b64 = combinedBuffer.toString('base64');
  
  return b64.split('').reverse().join('');
}

function decryptPayloadObj(obfuscatedBase64, keyString) {
  const b64 = obfuscatedBase64.split('').reverse().join('');
  const combinedBuffer = Buffer.from(b64, 'base64');
  
  const iv = combinedBuffer.subarray(0, 12);
  const tag = combinedBuffer.subarray(12, 28);
  const cipherText = combinedBuffer.subarray(28);
  
  const sha256Buffer = createHash('sha256').update(keyString).digest();
  const decipher = createDecipheriv('aes-256-gcm', sha256Buffer, iv);
  decipher.setAuthTag(tag);
  
  let decrypted = decipher.update(cipherText, undefined, 'utf8');
  decrypted += decipher.final('utf8');
  return JSON.parse(decrypted);
}

// PW Backend Deep Decryption
function decryptPWNode(encodedText, keyString) {
  const [ivHex, cipherHex] = encodedText.split(":");
  if (!ivHex || !cipherHex) throw new Error("Format is not iv:ciphertext");

  const iv = Buffer.from(ivHex, 'hex');
  const cipherText = Buffer.from(cipherHex, 'hex');

  const sha256Buffer = createHash('sha256').update(keyString).digest();
  const hexKey32 = Buffer.from(sha256Buffer.toString('hex').substring(0, 32));
  const paddedKey = Buffer.from(keyString.padEnd(32, '\0'));
  const paddedKey16 = Buffer.from(keyString.padEnd(16, '\0'));

  const keysToTry = [sha256Buffer, hexKey32, paddedKey, paddedKey16];

  for (let key of keysToTry) {
    try {
      const algo = key.length === 32 ? 'aes-256-gcm' : 'aes-128-gcm';
      const decipher = createDecipheriv(algo, key, iv);
      const tag = cipherText.subarray(cipherText.length - 16);
      const encrypted = cipherText.subarray(0, cipherText.length - 16);
      decipher.setAuthTag(tag);
      let decrypted = decipher.update(encrypted, undefined, 'utf8');
      decrypted += decipher.final('utf8');
      return decrypted;
    } catch(e) { }
  }
  throw new Error(`Exhausted all AES-GCM key derivation strategies.`);
}

async function readJson() {
  try {
    const raw = await readFile(DATA_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeJson(arr) {
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(DATA_FILE, JSON.stringify(arr, null, 2), 'utf8');
}

async function writeSecureToken(tokenStr) {
  const secureData = encryptPayload({ t: tokenStr }, expectedKeyHash);
  await mkdir(DATA_DIR, { recursive: true });
  await writeFile(DATA_TOKEN_FILE, JSON.stringify({ _s: secureData }), 'utf8');
}

async function readSecureToken() {
  try {
    const raw = await readFile(DATA_TOKEN_FILE, 'utf8');
    const parsed = JSON.parse(raw);
    if (!parsed._s) return null;
    const obj = decryptPayloadObj(parsed._s, expectedKeyHash);
    return obj.t;
  } catch {
    return null;
  }
}


async function ensureSeed() {
  const existing = await readJson();
  if (existing.length) return;
  const seeded = [
    {
      id: randomUUID(),
      title: 'Yakeen NEET 2027',
      subtitle: 'Class 12+ - NEET',
      examLabel: 'NEET 2027',
      language: 'HINGLISH',
      startDate: '2026-04-14',
      price: 5200,
      originalPrice: 6000,
      imageUrl:
        'https://static.pw.live/auth-fe/assets/images/pw_badge_v2_login.webp',
      createdAt: Date.now(),
    },
  ];
  await writeJson(seeded);
}

function send(res, status, body, headers = {}) {
  const json = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,DELETE,OPTIONS',
    'access-control-allow-headers': 'content-type,x-admin-key',
    ...headers,
  });
  res.end(json);
}

async function readBody(req) {
  return await new Promise((resolve, reject) => {
    let data = '';
    req.on('data', (c) => {
      data += c;
      if (data.length > 1_000_000) req.destroy();
    });
    req.on('end', () => resolve(data));
    req.on('error', reject);
  });
}

function requireAdmin(req) {
  const key = req.headers['x-admin-key'] || '';
  return sha256(key) === expectedKeyHash;
}

function isValidBatchInput(x) {
  if (!x || typeof x !== 'object') return false;
  const fields = [
    'title',
    'subtitle',
    'examLabel',
    'language',
    'startDate',
    'price',
    'originalPrice',
    'imageUrl',
  ];
  for (const f of fields) {
    if (!(f in x)) return false;
  }
  if (typeof x.title !== 'string' || !x.title.trim()) return false;
  if (typeof x.subtitle !== 'string' || !x.subtitle.trim()) return false;
  if (typeof x.examLabel !== 'string' || !x.examLabel.trim()) return false;
  if (typeof x.language !== 'string' || !x.language.trim()) return false;
  if (typeof x.startDate !== 'string' || !x.startDate.trim()) return false;
  if (typeof x.imageUrl !== 'string' || !x.imageUrl.trim()) return false;
  const p = Number(x.price);
  const op = Number(x.originalPrice);
  if (!Number.isFinite(p) || p <= 0) return false;
  if (!Number.isFinite(op) || op <= 0) return false;
  return true;
}

createServer(async (req, res) => {
  try {
    if (!req.url) return send(res, 404, { error: 'Not found' });
    if (req.method === 'OPTIONS') return send(res, 204, {});

    const url = new URL(req.url, `http://${req.headers.host}`);
    const path = url.pathname;

    if (req.method === 'GET' && path === '/api/health') {
      return send(res, 200, { ok: true });
    }

    if (req.method === 'GET' && path === '/api/batches') {
      const batches = await readJson();
      batches.sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0));
      return send(res, 200, batches);
    }

    if (req.method === 'POST' && path === '/api/batches') {
      if (!requireAdmin(req)) return send(res, 401, { error: 'Unauthorized' });
      const raw = await readBody(req);
      let body = null;
      try {
        body = raw ? JSON.parse(raw) : null;
      } catch {
        return send(res, 400, { error: 'Invalid JSON' });
      }
      if (!isValidBatchInput(body)) return send(res, 400, { error: 'Invalid input' });

      const batches = await readJson();
      const next = {
        id: randomUUID(),
        title: body.title.trim(),
        subtitle: body.subtitle.trim(),
        examLabel: body.examLabel.trim(),
        language: body.language.trim(),
        startDate: body.startDate.trim(),
        price: Number(body.price),
        originalPrice: Number(body.originalPrice),
        imageUrl: body.imageUrl.trim(),
        createdAt: Date.now(),
      };
      await writeJson([next, ...batches]);
      return send(res, 200, next);
    }

    if (req.method === 'DELETE' && path.startsWith('/api/batches/')) {
      if (!requireAdmin(req)) return send(res, 401, { error: 'Unauthorized' });
      const id = decodeURIComponent(path.slice('/api/batches/'.length));
      if (!id) return send(res, 400, { error: 'Invalid id' });
      const batches = await readJson();
      const next = batches.filter((b) => b && b.id !== id);
      await writeJson(next);
      return send(res, 200, { ok: true });
    }

    // --- IMPENETRABLE VIDEO & DRM PROXY LAYER ---
    
    // 1. Secure Media Metadata Endpoint
    if (req.method === 'GET' && path === '/api/v1/media-secure') {
       const batchId = url.searchParams.get('b');
       const subjectId = url.searchParams.get('s');
       const childId = url.searchParams.get('c');
       
       if (!batchId || !subjectId || !childId) return send(res, 400, { error: 'Missing parameters' });

       try {
           // Step A: Fetch PW Encrypted Video Object
           const fetchRes = await fetch(`https://apiserverpro.onrender.com/api/pw/video?batchId=${batchId}&subjectId=${subjectId}&childId=${childId}`);
           if (!fetchRes.ok) return send(res, fetchRes.status, { error: 'Upstream video rejection' });
           let vData = await fetchRes.json();
           
           // Step B: Decrypt PW Payload
           const decodedRaw = decryptPWNode(vData.data, "maggikhalo");
           let parsedObj = JSON.parse(decodedRaw);
           if (parsedObj.data) parsedObj = parsedObj.data;
           
           const mpdUrl = parsedObj.url;
           const signedUrlStr = parsedObj.signedUrl || "";
           const fullMpdObjUrl = mpdUrl + signedUrlStr;

           // Step C: Fetch KID
           const kidRes = await fetch(`https://apiserverpro.onrender.com/api/pw/kid?mpdUrl=${encodeURIComponent(fullMpdObjUrl)}`);
           const kidData = await kidRes.json();
           if (!kidData.kid) throw new Error("KID retrieval failed");

           // Step D: Fetch OTP Hex Key
           const otpRes = await fetch(`https://apiserverpro.onrender.com/api/pw/otp?kid=${kidData.kid}`);
           const otpData = await otpRes.json();
           if (!otpData.key) throw new Error("AES Key retrieval failed");

           // Step E: Generate JWT-style HLS Token
           const baseUrl = mpdUrl.replace('/master.mpd', '');
           const tokenPayload = { b: baseUrl, s: signedUrlStr };
           const jwtToken = Buffer.from(JSON.stringify(tokenPayload)).toString('base64url');

           // Step F: Encrypt and send our final custom JSON to the frontend
           const secureData = {
               streamUrl: `/stream/${jwtToken}/master.m3u8`,
               keyHex: otpData.key
           };

           const encryptedResponse = encryptPayload(secureData, "PiMaxerkiJay@@##*(^*&%^%$%#");
           return send(res, 200, { payload: encryptedResponse });

       } catch(e) {
           return send(res, 500, { error: 'Media DRM initialization failed', msg: e.message });
       }
    }

    // 2. Virtual HLS Stream Router
    if (req.method === 'GET' && path.startsWith('/stream/')) {
        // Path matches: /stream/{token}/{file.m3u8 or file.ts}
        const segments = path.split('/');
        // segments[0] = '', [1] = 'stream', [2] = token, [3...] = file paths
        if (segments.length < 4) return send(res, 400, { error: 'Invalid stream context' });

        const token = segments[2];
        const fileRoute = segments.slice(3).join('/');

        let tokenData;
        try {
            const decodedStr = Buffer.from(token, 'base64url').toString('utf8');
            tokenData = JSON.parse(decodedStr);
        } catch(e) {
            return send(res, 403, { error: 'Broken stream authorization token' });
        }

        const { b: baseUrl, s: signedUrlStr } = tokenData;
        const targetUrl = `${baseUrl}/${fileRoute}${signedUrlStr}`;

        try {
            const fetchRes = await fetch(targetUrl);
            const contentType = fetchRes.headers.get('content-type') || 'application/vnd.apple.mpegurl';
            
            res.setHeader('Content-Type', contentType);
            res.setHeader('Access-Control-Allow-Origin', '*');

            if (!fetchRes.ok) {
                res.writeHead(fetchRes.status);
                return res.end();
            }

            res.writeHead(200);
            if (fetchRes.body) {
               Readable.fromWeb(fetchRes.body).pipe(res);
               return;
            }
            return res.end();
        } catch(e) {
            return res.writeHead(500).end();
        }
    }

    // 3. Admin Token Endpoint
    if (req.method === 'POST' && path === '/api/v1/admin/settings/token') {
      if (!requireAdmin(req)) return send(res, 401, { error: 'Unauthorized' });
      const raw = await readBody(req);
      let body;
      try { body = JSON.parse(raw); } catch { return send(res, 400, { error: 'Invalid JSON' }); }
      if (!body.token) return send(res, 400, { error: 'No token' });
      
      await writeSecureToken(body.token);
      return send(res, 200, { ok: true });
    }

    // 4. Transparent Proxy Endpoint
    if (path.startsWith('/api/v1/pw-proxy/')) {
        const targetPath = url.pathname.replace('/api/v1/pw-proxy', '') + url.search;
        const targetUrl = `https://api.penpencil.co${targetPath}`;
        
        const activeToken = await readSecureToken();
        if (!activeToken) return send(res, 401, { success: false, message: 'PW Token missing in Server Vault. Please sync via Admin Panel.' });

        try {
            const pwReqHeaders = {};
            pwReqHeaders['authorization'] = `Bearer ${activeToken}`;
            pwReqHeaders['client-id'] = '5eb393ee95fab7468a79d189';
            pwReqHeaders['client-type'] = 'WEB';
            pwReqHeaders['client-version'] = '4.5.2';
            pwReqHeaders['content-type'] = 'application/json';
            pwReqHeaders['randomid'] = randomUUID();

            const fetchOpts = {
                method: req.method,
                headers: pwReqHeaders,
            };
            
            if (req.method !== 'GET' && req.method !== 'HEAD') {
                const rawBody = await readBody(req);
                fetchOpts.body = rawBody;
            }

            const fetchRes = await fetch(targetUrl, fetchOpts);
            const contentType = fetchRes.headers.get('content-type') || 'application/json';
            
            res.setHeader('Content-Type', contentType);
            res.setHeader('Access-Control-Allow-Origin', '*');
            
            if (fetchRes.body) {
                Readable.fromWeb(fetchRes.body).pipe(res);
                return;
            }
            return res.writeHead(fetchRes.status).end();

        } catch(e) {
            return send(res, 500, { success: false, message: 'Proxy failed', error: e.message });
        }
    }

    return send(res, 404, { error: 'Not found' });
  } catch (e) {
    return send(res, 500, { error: 'Server error' });
  }
}).listen(PORT, () => {
  process.stdout.write(`API running on http://localhost:${PORT}\n`);
});

ensureSeed().catch(() => {});

